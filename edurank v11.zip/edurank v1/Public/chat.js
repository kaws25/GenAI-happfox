const socket = io();

// Function to send a message
function sendMessage() {
    const messageInput = document.getElementById("message");
    const message = messageInput.value.trim();
    if (message) {
        socket.emit("chatMessage", message);  // Send message to server
        messageInput.value = "";  // Clear input box
    }
}

// Function to receive and display messages
socket.on("chatMessage", (msg) => {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("p");
    messageElement.textContent = msg;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;  // Auto-scroll to latest message
});
