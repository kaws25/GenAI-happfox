document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent default form submission

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const message = document.getElementById("message");

    fetch("https://hook.eu2.make.com/er0guqe85gygyt61ct39hjapyy5aq5q3", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ 
            email: email, 
            password: password 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            message.style.color = "green";
            message.textContent = "Login successful! Redirecting...";

            setTimeout(() => {
                window.location.href = "home.html"; // Redirect to home page
            }, 2000);
        } else {
            message.style.color = "red";
            message.textContent = "Invalid email or password!";
        }
    })
    .catch(error => {
        message.style.color = "red";
        message.textContent = "Error logging in. Try again!";
        console.error("Error:", error);
    });
});
