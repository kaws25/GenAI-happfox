let points = 0;
const pointsDisplay = document.getElementById("points");
const rankDisplay = document.getElementById("rank");

function updateRank() {
    let rank;
    rankDisplay.className = "rank-container";

    if (points <= 100) {
        rank = "Iron";
        rankDisplay.classList.add("iron");
    } else if (points <= 299) {
        rank = "Bronze";
        rankDisplay.classList.add("bronze");
    } else if (points <= 550) {
        rank = "Gold";
        rankDisplay.classList.add("gold");
    } else if (points <= 700) {
        rank = "Platinum";
        rankDisplay.classList.add("platinum");
    } else if (points <= 1000) {
        rank = "Diamond";
        rankDisplay.classList.add("diamond");
    } else if (points <= 1500) {
        rank = "Giternal";
        rankDisplay.classList.add("giternal");
    } else {
        rank = "Executive";
        rankDisplay.classList.add("executive");
    }

    rankDisplay.innerText = "Rank: " + rank;
}

function addPoints(amount) {
    points += amount;
    pointsDisplay.innerText = points;
    updateRank();
}