const socket = io();

// Function to send a message
function sendMessage() {
    let input = document.getElementById("messageInput");
    let message = input.value.trim();
    
    if (message) {
        socket.emit("chatMessage", message);  // Send message to server
        input.value = ""; // Clear input
    }
}

// Receive messages from the server
socket.on("chatMessage", (data) => {
    let chatBox = document.getElementById("chat-box");
    let newMessage = document.createElement("p");
    newMessage.innerHTML = `<strong>${data.user}:</strong> ${data.message}`;
    chatBox.appendChild(newMessage);
    chatBox.scrollTop = chatBox.scrollHeight;
});
